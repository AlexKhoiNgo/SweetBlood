
Note of the author
By installing or using this font, you are agree to the Product Usage Agreement:

- This font is DEMO FONT and ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase commercial license:
https://rissyletterstudio.com/product/sweet-matcha/

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
nurrohmanrizki5@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/Rissyletterstudio?locale.x=id_ID

Please visit our store for more amazing fonts :
https://rissyletterstudio.com

Follow our instagram for update : @nurrohmanrizki5@gmail.com

Thank you.

-------------------

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:   

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi